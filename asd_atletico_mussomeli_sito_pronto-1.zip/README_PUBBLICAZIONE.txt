ASD ATLETICO MUSSOMELI — SITO WEB

Contenuto:
- index.html              pagina principale
- assets/                 immagini e video del sito
- .nojekyll               configurazione utile per GitHub Pages

PUBBLICAZIONE CON GITHUB PAGES
1. Crea un nuovo repository pubblico su GitHub.
2. Carica TUTTO il contenuto di questa cartella nella radice del repository:
   index.html, .nojekyll e la cartella assets.
3. Nel repository apri Settings > Pages.
4. In "Build and deployment", scegli "Deploy from a branch".
5. Seleziona branch "main" e cartella "/ (root)", quindi salva.
6. Dopo la pubblicazione GitHub mostrerà l'indirizzo del sito.

IMPORTANTE
Una volta creato il QR code sull'indirizzo del sito, potrai aggiornare
foto, testi, squadra, partner, calendario e gadget senza cambiare il QR:
basterà aggiornare i file nello stesso repository.

Versione preparata per la presentazione ASD Atletico Mussomeli 2026/27.
